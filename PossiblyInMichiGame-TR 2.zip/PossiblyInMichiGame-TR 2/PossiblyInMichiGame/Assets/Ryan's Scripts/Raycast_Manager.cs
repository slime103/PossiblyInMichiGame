﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//INTENT: Basic raycast for picking up objects and talking to NPCS
//USAGE: Put this on a raycast manager to use inventory objects, pick up things or talk to people
public class Raycast_Manager : MonoBehaviour
{
    private RaycastHit target; //For storing the gameObject we're clicking 

    public Dialogue_Manager dialogueManager; //Get the dialogue manager

    public Inventory myInv;
    
    // Start is called before the first frame update
    void Start()
    {
        dialogueManager = GameObject.Find("Dialogue_Manager").GetComponent<Dialogue_Manager>(); //Get the dialogue manager
        myInv = GameObject.Find("Inventory").GetComponent<Inventory>();
    }

    // Update is called once per frame
    void Update()
    {
		
        Ray mouseRay = Camera.main.ScreenPointToRay(Input.mousePosition); //Gets mouse position

        float maxDistance = 1000f; //I made it really long bc it's just easier
        
        RaycastHit mouseRayHit = new RaycastHit(); //Instantiate the ray
        
        Debug.DrawRay(mouseRay.origin, mouseRay.direction * maxDistance, Color.cyan); //Draw it out so we can see it

        // Make the ray
        if (Physics.Raycast(mouseRay, out mouseRayHit, maxDistance)) 
        {
            if (dialogueManager.isTalkingTo == false)
            {
                if (mouseRayHit.collider.CompareTag("NPC"))
                {
                
                    //Later on I want to add a different mouse hover color so objects are more obviously clickable
                
                    //If left mouse button is clicked:
                    if (Input.GetMouseButton(0))
                    {
                        dialogueManager.SetCharacter(mouseRayHit.collider.gameObject); //Gets the dialogue holder from the Character
                        dialogueManager.dialogueBox.SetActive(true); //Turns on the dialogue box
                    }
                } //this is when TR starts writing stuff!
                else if (mouseRayHit.collider.tag.Contains("Item")) //Checking to see if you're scrolling over the item
                {
                    if (mouseRayHit.collider.gameObject.GetComponent<Item>().isCollected) //If this is an item you've already collected
                    {
                        //When you hold down the left mouse button, you can drag that bad boy around.
                        //if you release the mouse button while dragging the item, check to see if the mouse is over an NPC
                        //If it's not just run AddItem on it again
                        //If it is, interact with the NPC and see if they want the object or not
                        //If they do, destroy the object
                        //If they don't run AddItem on it again
                    }
                    else if(!mouseRayHit.collider.gameObject.GetComponent<Item>().isCollected) //If this is an item you haven't collected yet
                    {
                        if (Input.GetMouseButton(0)) //When you click on it
                        {
                            myInv.AddItem(mouseRayHit.collider.gameObject.GetComponent<Item>()); //Add it to your inventory
                        }
                    }
                }
            }

            //For when objects are introduced 
            /*if (mouseRayHit.collider.CompareTag("Object"))
            {
                
            }*/
            
        }

    }
}
