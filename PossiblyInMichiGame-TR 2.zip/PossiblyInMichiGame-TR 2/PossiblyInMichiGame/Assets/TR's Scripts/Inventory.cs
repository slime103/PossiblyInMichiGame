﻿using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;
using UnityEngine;
using Quaternion = UnityEngine.Quaternion;
using Vector3 = UnityEngine.Vector3;

public class Inventory : MonoBehaviour
{
    public Item[] myItems; //this contains (in this order): Quarter, Key, Gum, Baby, Shoe, Ear, Snail, and Perfume
    
    void Update()
    {
        if (Input.GetKey(KeyCode.Space))//Test to go through inventory and give information about each item
        {
            for (int i = 0; i < myItems.Length; i++)
            {
                Debug.Log(myItems[i].gameObject.tag + ": " + myItems[i].isCollected);
            }
        }
    }

    public void AddItem(Item itemToAdd)//Use when you click a non-collected item in a scene or when you receive an item from an NPC
    {
        switch (itemToAdd.gameObject.tag)
        {
            case "ItemQuarter":
                myItems[0] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[0].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
            case "ItemKey":
                myItems[1] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[1].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
            case "ItemGum":
                myItems[2] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[2].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
            case "ItemBaby":
                myItems[3] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[3].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
            case "ItemShoe":
                myItems[4] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[4].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
            case "ItemEar":
                myItems[5] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[5].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
            case "ItemSnail":
                myItems[6] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[6].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
            case "ItemPerfume":
                myItems[7] = Instantiate(itemToAdd, myItems[3].myPos, Quaternion.identity);
                myItems[7].isCollected = true;
                Destroy(itemToAdd.gameObject);
                break;
        }
    }
    
}
