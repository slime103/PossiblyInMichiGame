﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Item : MonoBehaviour
{
    private SpriteRenderer sr;
    public Sprite mySprite;
    public bool isCollected;
    public Vector2 myPos;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        sr.sprite = mySprite;
        isCollected = false;
        myPos = gameObject.transform.position;
    }
}